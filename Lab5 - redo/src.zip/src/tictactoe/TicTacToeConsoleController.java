package tictactoe;

import java.io.IOException;
import java.util.Objects;
import java.util.Scanner;

/**
 * Create a tictactoe console controller class.
 */
public class TicTacToeConsoleController implements TicTacToeController {
  private Appendable out;
  private Scanner scanner;

  /**
   * Constructor for tictactoe class.
   */
  public TicTacToeConsoleController(Readable r, Appendable out) {
    this.out = out;
    this.scanner = new Scanner(r);
  }

  /**
   * Method to check for valid input.
   */
  private boolean isValidInput(String input)
  {
    if (input.equalsIgnoreCase("q")) {
      return true;
    }
    else
    {
      try
      {
        int num = Integer.parseInt(input);
      }
      catch (NumberFormatException i)
      {
        return false;
      }
    }
    return true;
  }

  String token;
  String token2;


  /**
   * Play game method.
   */
  @Override
  public void playGame(TicTacToe m) throws IllegalStateException {
    Objects.requireNonNull(m);
    boolean flag = false;

    try {
      this.out.append(m.toString() + "\n");
    }
    catch (IOException e)
    {
      throw new IllegalStateException("IOException Error " + e);
    }

    while (!m.isGameOver())
    {
      try {
        this.out.append("Enter a move for " + m.getTurn().toString() + ":\n");
      }
      catch (IOException e) {
        throw new IllegalStateException("IOExeption error" + e);
      }

      token = scanner.next();
      if (!isValidInput(token))
      {
        token = "q";
        try {
          out.append("must be a number or q").append("\n");
        }
        catch (IOException e) {
          throw new IllegalStateException("IOError e: " + e);
        }
      }
      if (token.equalsIgnoreCase("q")) {
          break;
      }

      token2 = scanner.next();
      if (!isValidInput(token2)) {
        token2 = "q";
        try {
          out.append("Must be a number or q.").append("\n");
        }
        catch (IOException i) {
          throw new IllegalStateException("error");
        }
      }
      if (token2.equalsIgnoreCase("q")) {
        break;
      }
      try {
        int row = Integer.parseInt(token) - 1;
        int column = Integer.parseInt(token2) - 1;
        m.move(row, column);
      }
      catch (IllegalArgumentException e) {
        try {
          this.out.append("Invalid input provided - input mismatch.\n");
          flag = true;
        }
        catch (IOException i) {
          throw new IllegalStateException("IOException error: " + i);
        }
      }

      try {
        out.append(m.toString()).append("\n");
      }
      catch (IOException e) {
        throw new IllegalStateException("IOException error: " + e);
      }
      if (flag) {
        break;
      }
    }

    if (!m.isGameOver() && token.equalsIgnoreCase("q")) {
      try {
        this.out.append("Game quit! Ending game state:\n" + m.toString() + "\n");
      }
      catch (IOException i) {
        throw new IllegalStateException("error");
      }
    }
    else if (!m.isGameOver()) {
      throw new IllegalStateException("Out of inputs");
    }
    else {
      if (m.getWinner() == null) {
        try {
          this.out.append("Game is over! Tie game.\n");
        }
        catch (IOException e) {
          throw new IllegalStateException("IOException error: " + e);
        }
      }
      else {
        try {
          this.out.append("Game is over! " + m.getWinner() + " wins.\n");
        }
        catch (IOException i) {
          throw new IllegalStateException("error");
        }
      }
    }
  }
}
