package tictactoe;

import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Run a Tic Tac Toe game interactively on the console.
 */
public class Main {
  /**
   * Run a Tic Tac Toe game interactively on the console.
   */
  public static void main(String[] args) throws IOException {
    new TicTacToeConsoleController(new InputStreamReader(System.in),
        System.out).playGame(new TicTacToeModel());
  }
}
