package tictactoe;

/**
 * Create an enum class that will return player x or player o.
 */
public enum Player { X, O }
