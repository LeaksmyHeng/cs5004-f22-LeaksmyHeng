package doubledispatch;

import java.util.ArrayList;
import java.util.List;

public class SimulationBuilder {
  /* Instance list that could be appended to. */
  private static ArrayList<String> logs = new ArrayList<String>();
  public static void addToLog(String s) {
    logs.add(s);
  }

  public static IPlanet createPlanet(String name) {
    String lowerCaseName = name.toLowerCase();
    return switch (lowerCaseName) {
      case "mars" -> new Mars();
      case "mercury" -> new Mercury();
      case "venus" -> new Venus();
      default -> null;
    };
  }

  public static ISpaceExplorer createExplorer(String name) {
    /* Could be LifeExplorer or TerrainExplorer*/
    String lowerCaseExplorer = name.toLowerCase();
    return switch (lowerCaseExplorer) {
      case "terrainexplorer" -> new TerrainExplorer();
      case "lifeexplorer" -> new LifeExplorer();
      default -> null;
    };
  }

  public static List<String> getSimulationLog() {
    return logs;
  }
}
