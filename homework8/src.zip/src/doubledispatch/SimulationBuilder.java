package doubledispatch;

import java.util.List;

public class SimulationBuilder {
  public static void addToLog(String s) {
  }

  public static IPlanet createPlanet(String name) {
    return null;
  }

  public static ISpaceExplorer createExplorer(String name) {
    return null;
  }

  public static List<String> getSimulationLog() {
    return null;
  }
}
