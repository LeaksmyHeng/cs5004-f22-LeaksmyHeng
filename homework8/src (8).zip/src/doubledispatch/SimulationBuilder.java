package doubledispatch;

import java.util.ArrayList;
import java.util.List;

public class SimulationBuilder {
  private static final ArrayList<String> logs = new ArrayList<String>();
  public static void addToLog(String s) {
    logs.add(s);
  }

  public static IPlanet createPlanet(String name) {
    String lowerCaseName = name.toLowerCase();
    if (lowerCaseName.equals("mars")) {
      return new Mars();
    }
    else if (lowerCaseName.equals("mercury")) {
      return new Mercury();
    }
    else if (lowerCaseName.equals("venus")) {
      return new Venus();
    }
    else return null;
  }

  public static ISpaceExplorer createExplorer(String name) {
    String lowerCaseExplorer = name.toLowerCase();
    if (lowerCaseExplorer.equals("terrainexplorer")) {
      return new TerrainExplorer();
    }
    else if (lowerCaseExplorer.equals("lifeexplorer")) {
      return new LifeExplorer();
    }
    return null;
  }

  public static List<String> getSimulationLog() {
    return logs;
  }
}
