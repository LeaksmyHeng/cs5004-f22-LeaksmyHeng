import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import employee.Employee;

/**
 * This is a test for Employee class.
 */
public class testEmployee {
  private Employee leaksmy;
  private Employee daniel;
  private Employee peter;
  private Employee mark;
  private Employee rana;
  private Employee darny;

  /**
   * Setting up the Employee class.
   */
  @Before
  public void setUp() {
    leaksmy = new Employee("Smy", "E0001", 89000.00, 2, false);
    daniel = new Employee("Dan", "E0002", 79255.25, 4, false);
    peter = new Employee("Peter", "E0003", 96250.25, 1, false);
    mark = new Employee("Mark", "M0001", 125250.25, 2, true);
    rana = new Employee("Rana", "E0004", 29.25, 40.00);
    darny = new Employee("Darny", "E0005", 32.25, 40.00);
  }

  /**
   * Test isManager for Salaried Employee.
   */
  @Test
  public void testManager() {
    assertTrue(mark.isManager());
    assertFalse(leaksmy.isManager());
    assertFalse(peter.isManager());
    assertFalse(daniel.isManager());
    assertFalse(darny.isManager());
    assertFalse(rana.isManager());
  }
}
