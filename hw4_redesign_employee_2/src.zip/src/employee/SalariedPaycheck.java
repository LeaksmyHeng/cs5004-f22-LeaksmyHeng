package employee;

/**
 * Create a salariedy paycheck class.
 */
public class SalariedPaycheck extends AbstractPaycheck implements IPaycheck{
  public SalariedPaycheck(double payRate, int payInterval) {
    super(payRate, payInterval);
  }
}
