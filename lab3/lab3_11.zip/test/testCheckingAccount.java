import org.junit.Before;
import org.junit.Test;

import bank.SavingsAccount;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class testCheckingAccount {
  SavingsAccount leaksmy;
  SavingsAccount daniel;
  SavingsAccount peter;

  @Before
  public void setUp() {
    leaksmy = new SavingsAccount(100);
    daniel = new SavingsAccount(20.00);
    peter = new SavingsAccount(0.011);
  }

  @Test
  public void testCreateSavingAccount() {
    assertEquals(100.00, leaksmy.getBalance(), 0.01);
    assertEquals(20.00, daniel.getBalance(), 0.01);
    assertEquals(0.011, peter.getBalance(), 0.01);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalStarterAmount() {
    SavingsAccount badSavingAmount = new SavingsAccount(0.005);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalStarterAmount2() {
    SavingsAccount badSavingAmount = new SavingsAccount(0.00999);
  }

  @Test
  public void testIllegalWithdraw() {
    assertFalse(leaksmy.withdraw(-10.00));
    assertTrue(leaksmy.withdraw(10.00));
  }

}
