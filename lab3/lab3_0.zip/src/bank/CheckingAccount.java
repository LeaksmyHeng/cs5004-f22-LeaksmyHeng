package bank;

public class CheckingAccount extends AbstractAccount implements IAccount{

  public CheckingAccount(double starterAmount) {
    super(starterAmount);
  }

  @Override
  public void deposit(double amount) {
    this.depositAmount(amount);
  }

  @Override
  public boolean withdraw(double amount) {
    this.checkWithdrawAmount(amount);
    if (amount < this.getBalance()) {
      balance = this.balance - amount;
      return true;
    }
    return false;
  }

  @Override
  public double getBalance() {
    return this.balance;
  }

  @Override
  public void performMonthlyMaintenance() {
    if (this.getBalance() < 100) {
      this.balance = this.getBalance() - 5;
    }
  }
}
