package bank;

public abstract class AbstractAccount implements IAccount {
  double balance;

  public AbstractAccount(double amount) throws IllegalArgumentException{
    if (amount < 0.01) {
      throw new IllegalArgumentException("Starter amount needs to be greater than 1 cent");
    }
    this.balance = amount;
  }

  protected double depositAmount(double amount) throws IllegalArgumentException{
    if (amount < 0) {
      throw new IllegalArgumentException("Deposit amount needs to be greater than 1 cent");
    }
    balance = this.getBalance() + amount;
    return balance;
  }

  protected void checkWithdrawAmount(double amount) throws IllegalArgumentException{
    if (amount < 0) {
      throw new IllegalArgumentException("Deposit amount needs to be greater than 1 cent");
    }
  }
}
