package bank;

import java.text.DecimalFormat;

/**
 * Implement a CheckingAccount class.
 */
public class CheckingAccount extends AbstractAccount implements IAccount {
  private final double MINIMUM_BALANCE = 100.00;
  private final double PENALTY_FEE = 5.00;
  private boolean PENALTY_APPLY;

  /**
   * Create a construct for CheckingAccount by taking one argument: starterAmount. Initialize the
   * penaltyTransaction to 0.
   */
  public CheckingAccount(double starterAmount) {
    super(starterAmount);
    this.PENALTY_APPLY = false;
    if (starterAmount < MINIMUM_BALANCE) {
      this.PENALTY_APPLY = true;
    }
  }

  @Override
  public void deposit(double amount) {
    this.depositAmount(amount);
    if (this.getBalance() < MINIMUM_BALANCE) {
      this.PENALTY_APPLY = true;
    }
  }

  @Override
  public boolean withdraw(double amount) {
    if (amount <= this.getBalance()) {
      balance = this.getBalance() - amount;
      if (this.getBalance() < MINIMUM_BALANCE) {
        this.PENALTY_APPLY = true;
      }
      return true;
    }
    return false;
  }

  @Override
  public double getBalance() {
    return this.balance;
  }

  @Override
  public void performMonthlyMaintenance() {
    if (this.PENALTY_APPLY) {
      this.balance = this.getBalance() - PENALTY_FEE;
    }
  }

  /**
   * Create a toString method for both account: saving and checking.
   */
  public String toString() {
    DecimalFormat moneyFormat = new DecimalFormat("$0.00");
    return moneyFormat.format(this.getBalance());
  }
}
