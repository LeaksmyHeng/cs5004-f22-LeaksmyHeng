package bank;

/**
 * Implement a CheckingAccount class.
 */
public class CheckingAccount extends AbstractAccount implements IAccount {
  private double penaltyTransaction;

  /**
   * Create a construct for CheckingAccount by taking one argument: starterAmount. Initialize the
   * penaltyTransaction to 0.
   */
  public CheckingAccount(double starterAmount) {
    super(starterAmount);
    this.penaltyTransaction = 0.00;
  }

  @Override
  public void deposit(double amount) {
    double penaltyTransactions = 5.00;
    if (amount < 100) {
      this.penaltyTransaction = penaltyTransactions + this.penaltyTransaction;
    }
    this.depositAmount(amount);
  }

  @Override
  public boolean withdraw(double amount) {
    checkWithdrawAmount(amount);
    double penaltyTransactions = 5.00;
    if (amount < this.getBalance()) {
      balance = this.balance - amount;
      return true;
    }
    if (this.getBalance() < 100) {
      this.penaltyTransaction = this.penaltyTransaction + penaltyTransactions;
    }
    return false;
  }

  @Override
  public double getBalance() {
    return this.balance;
  }

  @Override
  public void performMonthlyMaintenance() {
    if (this.getBalance() < 100) {
      this.balance = this.getBalance() - this.penaltyTransaction;
      this.penaltyTransaction = 0.0;
    }
  }
}
