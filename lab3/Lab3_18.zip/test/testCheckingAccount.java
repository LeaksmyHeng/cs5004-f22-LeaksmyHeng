import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import bank.CheckingAccount;


import org.junit.Before;
import org.junit.Test;

/**
 * This is a test for Checking Account.
 */
public class testCheckingAccount {
  CheckingAccount leaksmy;
  CheckingAccount daniel;
  CheckingAccount peter;

  /**
   * Setting up test for Checking Account.
   */
  @Before
  public void setUp() {
    leaksmy = new CheckingAccount(200.00);
    daniel = new CheckingAccount(100.00);
    peter = new CheckingAccount(50.00);
  }

  /**
   * Create a test for the get balance.
   */
  @Test
  public void testGetBalance() {
    assertEquals(200.00, leaksmy.getBalance(), 0.01);
    assertEquals(100.00, daniel.getBalance(), 0.01);
    assertEquals(50.00, peter.getBalance(), 0.01);
  }

  /**
   * Create Illegal argument for Starting a Saving Account.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalStarterAmount() {
    CheckingAccount badSavingAmount = new CheckingAccount(0.005);
  }

  /**
   * Create Illegal argument for Starting a Saving Account.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalStarterAmount2() {
    CheckingAccount badSavingAmount = new CheckingAccount(0.00999);
  }

  /**
   * Create a withdrawal test.
   */
  @Test
  public void testWithdraw() {
    assertFalse(peter.withdraw(190.00));
    assertFalse(daniel.withdraw(150.00));
    assertEquals(200.00, leaksmy.getBalance(), 0.01);
    assertEquals(50.00, peter.getBalance(), 0.01);
    assertEquals("$200.00", leaksmy.toString());
  }

  /**
   * Create a withdrawal with penalty test.
   */
  @Test
  public void testWithdrawWithPenalty() {
    assertTrue(leaksmy.withdraw(10.00));
    assertTrue(leaksmy.withdraw(50.00));
    assertTrue(leaksmy.withdraw(20.00));
    assertTrue(leaksmy.withdraw(50.00));
    leaksmy.deposit(250);
    assertEquals(320.00, leaksmy.getBalance(), 0.01);
    leaksmy.performMonthlyMaintenance();
    assertEquals(315, leaksmy.getBalance(), 0.01);
    assertEquals("$315.00", leaksmy.toString());
  }

  /**
   * Create a withdrawal with penalty test and negative account.
   */
  @Test
  public void testWithdrawWithPenaltyAndNegativeAccount() {
    assertTrue(leaksmy.withdraw(50.00));
    assertTrue(leaksmy.withdraw(50.00));
    assertTrue(leaksmy.withdraw(50.00));
    assertTrue(leaksmy.withdraw(50.00));
    assertEquals(0.00, leaksmy.getBalance(), 0.01);
    leaksmy.performMonthlyMaintenance();
    assertEquals(-5.00, leaksmy.getBalance(), 0.01);
    assertEquals("-$5.00", leaksmy.toString());
    leaksmy.deposit(1.00);
    assertEquals("-$4.00", leaksmy.toString());
  }
}
