package bank;

import java.text.DecimalFormat;

/**
 * Implement a CheckingAccount class.
 */
public class CheckingAccount extends AbstractAccount implements IAccount {
  private double penaltyTransaction;
  private double checkingWithdrawAmount;

  /**
   * Create a construct for CheckingAccount by taking one argument: starterAmount. Initialize the
   * penaltyTransaction to 0.
   */
  public CheckingAccount(double starterAmount) {
    super(starterAmount);
    this.penaltyTransaction = 0.00;
    this.checkingWithdrawAmount = 0.00;
  }

  @Override
  public void deposit(double amount) {
    double penaltyTransactions = 5.00;
    double amountThreshold = 100.00;
    if (amount < amountThreshold) {
      this.penaltyTransaction = penaltyTransactions + this.penaltyTransaction;
    }
    this.depositAmount(amount);
  }

  @Override
  public boolean withdraw(double amount) {
    if (amount > this.checkingWithdrawAmount) {
      if (amount <= this.getBalance()) {
        balance = this.balance - amount;
        return true;
      }
      return false;
    }
    return false;
  }

  @Override
  public double getBalance() {
    double amountThreshold = 100.00;
    double penaltyTransactions = 5.00;
    if (this.balance < amountThreshold) {
      this.penaltyTransaction = this.penaltyTransaction + penaltyTransactions;
    }
    return this.balance;
  }

  @Override
  public void performMonthlyMaintenance() {
      this.balance = this.getBalance() - this.penaltyTransaction;
  }

  /**
   * Create a toString method for both account: saving and checking.
   */
  public String toString() {
    DecimalFormat moneyFormat = new DecimalFormat("$0.00");
    return moneyFormat.format(this.getBalance());
  }
}
