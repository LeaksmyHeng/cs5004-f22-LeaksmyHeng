package bank;

/**
 * Implement a CheckingAccount class.
 */
public class CheckingAccount extends AbstractAccount implements IAccount {
  private double penaltyTransaction;

  /**
   * Create a construct for CheckingAccount by taking one argument: starterAmount. Initialize the
   * penaltyTransaction to 0.
   */
  public CheckingAccount(double starterAmount) {
    super(starterAmount);
    this.penaltyTransaction = 0.00;
    double penaltyTransaction = 14.00;
    if (starterAmount < 100) {
      this.penaltyTransaction = penaltyTransaction + this.penaltyTransaction;
    }
  }

  @Override
  public void deposit(double amount) {
    double penaltyTransaction = 14.00;
    if (amount < 100) {
      this.penaltyTransaction = penaltyTransaction + this.penaltyTransaction;
    }
    this.depositAmount(amount);
  }

  @Override
  public boolean withdraw(double amount) {
    checkWithdrawAmount(amount);
    double penaltyTransaction = 14.00;
    if (amount < this.getBalance()) {
      balance = this.balance - amount;
      return true;
    }
    if (this.getBalance() < 100) {
      this.penaltyTransaction = this.penaltyTransaction + penaltyTransaction;
    }
    return false;
  }

  @Override
  public double getBalance() {
    return this.balance;
  }

  @Override
  public void performMonthlyMaintenance() {
    if (this.getBalance() < 100) {
      this.balance = this.getBalance() - this.penaltyTransaction;
    }
  }
}
