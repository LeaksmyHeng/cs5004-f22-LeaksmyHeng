package bank;

import java.text.DecimalFormat;

/**
 * Implement a CheckingAccount class.
 */
public class CheckingAccount extends AbstractAccount implements IAccount {
  private final double MINIMUM_BALANCE = 100.00;
  private final double PENALTY_FEE = 5.00;
  private boolean PENALTY;

  /**
   * Create a construct for CheckingAccount by taking one argument: starterAmount. Initialize the
   * penaltyTransaction to 0.
   */
  public CheckingAccount(double starterAmount) {
    super(starterAmount);
    this.PENALTY = false;
    if (starterAmount < MINIMUM_BALANCE) {
      this.PENALTY = true;
    }
  }

  @Override
  public void deposit(double amount) {
    this.depositAmount(amount);
    if (this.getBalance() < MINIMUM_BALANCE) {
      this.PENALTY = true;
    }
  }

  @Override
  public boolean withdraw(double amount) {
    if (amount <= this.getBalance()) {
      balance = this.balance - amount;
      if (this.getBalance() < MINIMUM_BALANCE) {
        this.PENALTY = true;
      }
      return true;
    }
    return false;
  }

  @Override
  public double getBalance() {
    return this.balance;
  }

  @Override
  public void performMonthlyMaintenance() {
    if (this.PENALTY) {
      this.balance = this.getBalance() - PENALTY_FEE;
    }
  }

  /**
   * Create a toString method for both account: saving and checking.
   */
  public String toString() {
    DecimalFormat moneyFormat = new DecimalFormat("$0.00");
    return moneyFormat.format(this.getBalance());
  }
}
