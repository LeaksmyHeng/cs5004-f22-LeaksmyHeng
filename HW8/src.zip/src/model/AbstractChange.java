package model;

/**
 * Create an abstract class which we will use in the IPhotoAlbum.
 * startTimeFrame is when the shape start to appear.
 * endTimeFrame is when the shape stop appearing.
 * The compare to method will help when we build the view - further description is below.
 */
public class AbstractChange implements IChange, Comparable<AbstractChange> {
  private final IShape shape;
  private final int startTimeFrame;
  private final int endTimeFrame;

  public AbstractChange(IShape shape, int startTimeFrame, int endTimeFrame) {
    if (endTimeFrame < startTimeFrame) {
      throw new IllegalArgumentException("End time cannot be less than start time.");
    }
    if (endTimeFrame < 0 || startTimeFrame < 0) {
      throw new IllegalArgumentException("Start time and end time cannot be negative.");
    }
    if (shape == null) {
      throw new IllegalArgumentException("Shape cannot be null.");
    }
    this.shape = shape;
    this.startTimeFrame = startTimeFrame;
    this.endTimeFrame = endTimeFrame;
  }

  @Override
  public IShape getShapeID() {
    return this.shape;
  }

  @Override
  public String getShapeName() {
    return this.shape.shapeName();
  }

  @Override
  public int getStartTimeFrame() {
    return this.startTimeFrame;
  }

  @Override
  public int getEndTimeFrame() {
    return this.endTimeFrame;
  }

  /**
   * CompareTo method will help us in the view as it will help showing when the color change.
   */
  @Override
  public int compareTo(AbstractChange o) {
    int timeDiff = this.startTimeFrame - o.startTimeFrame;
    if (timeDiff == 0) {
      timeDiff = this.endTimeFrame - o.endTimeFrame;
    }
    return timeDiff;
  }
}
