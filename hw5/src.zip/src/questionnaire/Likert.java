package questionnaire;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Create a class for the Likert question.
 */
public class Likert extends AbstractQuestion implements Question {
  private String answer;
  /**
   * Create the constructor for the Question.
   *
   * @param question
   * @param required
   */
  public Likert(String question, boolean required) throws IllegalArgumentException {
    super(question, required);
    this.answer = "";
  }

  public static ArrayList<LikertResponseOption> myList() {
    ArrayList<LikertResponseOption> List = new ArrayList<>(Arrays.asList(LikertResponseOption.values()));
    return List;
  }

  @Override
  public void answer(String answer) throws IllegalArgumentException {
    if (answer != null) {
      for (int i = 0; i < myList().size(); i++) {
        String list = String.valueOf(myList().get(i));
        if (answer.equalsIgnoreCase(list)) {
          this.answer = answer;
        }
      }
    }
    throw new IllegalArgumentException("Answer cannot be null");
  }

  @Override
  public Question copy() {
    Question likertAnswerQuestion = new Likert(getPrompt(), isRequired());
    if (!getAnswer().equals("")) {
      likertAnswerQuestion.answer(getAnswer());
    }
    return likertAnswerQuestion;
  }
}
