import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import java.util.NoSuchElementException;

import questionnaire.Likert;
import questionnaire.QuestionnaireImpl;
import questionnaire.ShortAnswer;
import questionnaire.YesNo;

/**
 * Create a test for Question (YesNo, ShortAnswer, and Likert).
 */
public class testQuestion {
  private YesNo yes;
  private YesNo no;
  private YesNo yesNo;
  private ShortAnswer shortAnswer1;
  private ShortAnswer shortAnswer2;
  private Likert likert1;
  private Likert likert2;

  /**
   * Setting up the Questions test along with add it to Questionnaire list.
   */
  @Before
  public void setUp() {
    yes = new YesNo("Are you Leaksmy?", true);
    no = new YesNo("Are you an immortal?", true);
    yesNo = new YesNo("Is your IQ over 150?", false);
    shortAnswer1 = new ShortAnswer("Tell me about yourself.", true);
    shortAnswer2 = new ShortAnswer("Tell me about your daily job.", false);
    likert1 = new Likert("Do you believe in ghost?", true);
    likert2 = new Likert("Do you believe that Alient exist", false);
  }

  /**
   * Create test for getPrompt method.
   */
  @Test
  public void testGetPrompt() {
    assertEquals("Are you Leaksmy?Are you an immortal?Is your IQ over 150?",
            yes.getPrompt() + no.getPrompt() + yesNo.getPrompt());
    assertEquals("Tell me about yourself.", shortAnswer1.getPrompt());
    assertEquals("Do you believe in ghost?", likert1.getPrompt());
  }

  /**
   * Create test for getAnswer method.
   */
  @Test
  public void testIsRequired() {
    assertTrue(yes.isRequired() && no.isRequired() && shortAnswer1.isRequired());
    assertTrue(!yesNo.isRequired() && !shortAnswer2.isRequired());
    assertFalse(likert2.isRequired());
  }

  /**
   * Create a test to answer Yes No question.
   */
  @Test
  public void testGetAnswer() {
    yes.answer("Yes");
    no.answer("nO");
    yesNo.answer("yES");
    assertEquals("Yes", yes.getAnswer());
    assertEquals("nO", no.getAnswer());
    // Answer for short answer.
    shortAnswer1.answer("Hello my name is leaksmy Heng. I am from Cambodia.");
    assertEquals("Hello my name is leaksmy Heng. I am from Cambodia.",
            shortAnswer1.getAnswer());
    assertEquals("", shortAnswer2.getAnswer());
    // Answer for Likert.
    likert1.answer("disAGREE");
    assertEquals("disAGREE", likert1.getAnswer());
    assertEquals("", likert2.getAnswer());
  }

  /**
   * Test copy function for every questions type.
   */
  @Test
  public void testCopy() {
    // Yes no questions testing
    assertEquals(yes.getPrompt() + yes.getAnswer(),
            yes.copy().getPrompt() + yes.copy().getAnswer());
    assertEquals(no.getPrompt() + no.getAnswer(),
            no.copy().getPrompt() + no.copy().getAnswer());
    assertEquals(yesNo.getPrompt() + yesNo.getAnswer(),
            yesNo.copy().getPrompt() + yesNo.copy().getAnswer());
    assertEquals("", yesNo.copy().getAnswer());
    // short answer testing
    assertEquals(shortAnswer1.getAnswer() + shortAnswer1.getAnswer(),
            shortAnswer1.copy().getAnswer() + shortAnswer1.copy().getAnswer());
    assertEquals("", shortAnswer1.copy().getAnswer());
    // Likert copy answer testing
    assertEquals(likert1.getAnswer() + likert1.getAnswer(),
            likert1.copy().getAnswer() + likert1.copy().getAnswer());
    assertEquals("", likert2.copy().getAnswer());
  }

  /**
   * Test Illegal Answer for Yes No.
   */
  @Test (expected = IllegalArgumentException.class)
  public void testIllegalAnswertoYesNo() {
    yes.answer("I am Leaksmy.");
  }

  /**
   * Test Illegal Answer for Yes No.
   */
  @Test (expected = IllegalArgumentException.class)
  public void testIllegalAnswertoYesNo1() {
    no.answer(null);
  }

  /**
   * Test short answer out of bound.
   */
  @Test (expected = IllegalArgumentException.class)
  public void testAnswerOutOfBound() {
    shortAnswer1.answer("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
            + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
            + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
            + "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
            + "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"
            + "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd"
            + "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"
            + "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
            + "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
  }

  /**
   * Test short answer null.
   */
  @Test (expected = IllegalArgumentException.class)
  public void testShortAnswerNull() {
    shortAnswer1.answer(null);
  }

  /**
   * Test likert null answer.*/
  @Test (expected = IllegalArgumentException.class)
  public void testLikertNull() {
    likert2.answer(null);
  }

  /**
   * Test Likert answer not in likert.
   */
  @Test (expected = IllegalArgumentException.class)
  public void testLikertAnswerNotInEnum() {
    likert2.answer("I believe in that");
  }

  /**
   * Test yesNo Likert and shortAnswer.
   */
  @Test (expected = IllegalArgumentException.class)
  public void testAllEmptyStringAnswer() {
    shortAnswer1.answer("");
    yes.answer("");
    likert2.answer("");
  }

  // Initialize Questionnaire
  private QuestionnaireImpl questionList;

  /**
   * Setup the questionnaire test.
   */
  @Before
  public void setUpQuestionnaire() {
    // get all the YesNo, shortAnswer and Likert to the Questionnaire
    questionList = new QuestionnaireImpl();
    questionList.addQuestion("01", yes);
    questionList.addQuestion("02", yesNo);
    questionList.addQuestion("03", shortAnswer1);
    questionList.addQuestion("04", shortAnswer2);
    questionList.addQuestion("05", likert1);
    questionList.addQuestion("06", likert2);
  }

  /**
   * Test to see all 6 questions are added successfully.
   */
  @Test
  public void testAddQuestion() {
    // test get size of the list
    assertEquals(3, questionList.getRequiredQuestions().size());
    assertEquals(3, questionList.getOptionalQuestions().size());
  }

  /**
   * Create a test for getIdentifier.
   */
  @Test
  public void testGetIdentifier() {
    assertEquals("01", questionList.getIdentifier(yes));
    assertNotEquals("02", questionList.getIdentifier(shortAnswer2));
  }

  /**
   * Test remove question by identifier.
   */
  @Test
  public void testRemoveQuestion() {
    questionList.removeQuestion("01");
    assertEquals(2, questionList.getRequiredQuestions().size());
  }

  /**
   * Test when there is no identifier for the questions.
   */
  @Test (expected = NoSuchElementException.class)
  public void testRemoveQuestionOutOfBound() {
    questionList.removeQuestion("100");
  }
}
