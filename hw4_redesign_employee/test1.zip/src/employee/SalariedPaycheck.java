package employee;

/**
 * Create the SalariedPaycheck class that adhere to the IPaycheck interface.
 */
public class SalariedPaycheck implements IPaycheck {
  private double payRate;
  private double payInterval;

  /**
   * Create a constructor for SalariedPaycheck class.
   */
  public SalariedPaycheck(double payRate, double payInterval) {
    this.payRate = payRate;
    this.payInterval = payInterval;

    if (payRate < 0) {
      throw new IllegalArgumentException("Pay rate cannot be less than 0");
    }
  }

  @Override
  public double getTotalPay() {
    return 0;
  }

  @Override
  public double getPayAfterTaxes() {
    return 0;
  }

  @Override
  public double getPayRate() {
    return this.payRate;
  }
}
