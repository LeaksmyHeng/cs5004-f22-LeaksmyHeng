package employee;

/**
 * Create an Employee class that represents both hourly and salaried employee.
 */
public class Employee extends AbstractEmployee implements IEmployee{
  public Employee (String name, String id, double payRate, int payInterval, boolean isManager) {
    super(name, id, payRate, payInterval, isManager);
  }

  public Employee (String name, String id, double payRate, double hoursWorked) {
    super(name, id, payRate, hoursWorked);
  }

  @Override
  public IPaycheck getPayCheck() {
    return null;
  }

  /**
   * Create a toString method for Employee class.
   */
  public String toString() {
    return "Name: " + this.getName() + "\n" + "ID: " + this.getId() + "\n" +
            this.getPayCheck().toString();
  }
}

