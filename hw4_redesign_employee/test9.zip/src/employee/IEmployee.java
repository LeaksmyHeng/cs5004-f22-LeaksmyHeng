package employee;

/**
 * Create an interface for employee class.
 */
public interface IEmployee {
  /**
   * Check wether the employee is a manager.
   */
  public boolean isManager();
  /**
   * Create a method to check employee's paycheck.
   */
  public IPaycheck getPayCheck();
}
