/**
 * This is a test for Paycheck class.
 */

public class testPaycheck {
}
