package employee;

/**
 * Create an interface for paycheck class.
 */
public interface IPaycheck {
  /**
   * A method to get the total pay.
   */
  double getTotalPay();
  
  /**
   * A method to get the paycheck after tax is deducted.
   */

  double getPayAfterTaxes();

  /**
   * A method to get the payrate.
   */
  double getPayRate();
}
