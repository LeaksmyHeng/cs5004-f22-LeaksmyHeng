package employee;

import java.text.DecimalFormat;

/**
 * Create the SalariedPaycheck class that adhere to the IPaycheck interface.
 */
public class SalariedPaycheck implements IPaycheck {
  private double payRate;
  private double payInterval;

  private final double MINIMUM_PAYRATE = 0.00;

  /**
   * Create a constructor for SalariedPaycheck class.
   */
  public SalariedPaycheck(double payRate, double payInterval) {
    this.payRate = payRate;
    this.payInterval = payInterval;

    if (payRate < MINIMUM_PAYRATE) {
      throw new IllegalArgumentException("Pay rate cannot be less than 0");
    }
  }

  @Override
  public double getTotalPay() {
    double totalPay = MINIMUM_PAYRATE;
    int FULL_WEEK = 52;
    int WEEKLY = 1;
    if (this.payInterval == WEEKLY) {
      totalPay = (this.payRate / FULL_WEEK);
    }
    int BI_WEEKLY = 2;
    if (this.payInterval == BI_WEEKLY) {
      totalPay = (this.payRate / FULL_WEEK) * BI_WEEKLY;
    }
    int QUAD_WEEKLY = 4;
    if (this.payInterval == QUAD_WEEKLY) {
      totalPay = (this.payRate / FULL_WEEK) * QUAD_WEEKLY;
    }
    return totalPay;
  }

  @Override
  public double getPayAfterTaxes() {
    double getTotalPay = getTotalPay();
    double payAfterTax = MINIMUM_PAYRATE;
    double oneCent = 0.01;
    if (getTotalPay < 400) {
      double AFTER_TAX_MINIMUM = 0.90;
      payAfterTax = AFTER_TAX_MINIMUM * getTotalPay;
    }
    else if (getTotalPay >= 400) {
      double AFTER_TAX_MAXIMUM = 0.85;
      payAfterTax = getTotalPay * AFTER_TAX_MAXIMUM;
    }
    if ((MINIMUM_PAYRATE < payAfterTax) && (payAfterTax < oneCent)) {
      payAfterTax = oneCent;
    }
    return payAfterTax;
  }

  @Override
  public double getPayRate() {
    return this.payRate;
  }

  /**
   * Create a two string method for Salaried Paycheck.
   */
  public String toString() {
    DecimalFormat dec = new DecimalFormat("$ 0.00");
    return  "Payment after taxes: " + dec.format(getPayAfterTaxes());
  }
}
