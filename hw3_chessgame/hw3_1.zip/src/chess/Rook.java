package chess;

public class Rook extends AbstractPiece implements ChessPiece {

  public Rook(int row, int column, Color color) {
    super(row, column, color);
  }

  @Override
  public boolean canMove(int row, int col) {
    if (super.canMove(row, col) && ((this.getRow() != row && this.getColumn() == col)
            || (this.getRow() == row && this.getColumn() != col))) {
      return true;
    }
    return false;
  }

  @Override
  public boolean canKill(ChessPiece piece) {
    return super.canKill(piece) && this.canMove(piece.getRow(), piece.getColumn());
  }

}
