package chess;

public class Pawn extends AbstractPiece implements ChessPiece {
  public Pawn(int row, int column, Color color) {
    super(row, column, color);
  }

  @Override
  public boolean canMove(int row, int column) {
    if (super.canMove(row, column)) {
      if ((this.getRow() == 1 && this.getColor() == Color.WHITE) || (this.getRow() == 6 && this.getColor() == Color.BLACK)) {
        if (this.getColumn() == column && row - this.getRow() <= 2) {
          return true;
        }
      }
      else {
        if ((this.getColumn() == column && row - this.getRow() == 1)) {
          return true;
        }
      }
    }
    return false;
  }

  @Override
  public boolean canKill(ChessPiece piece) {
    return super.canKill(piece) && piece.getRow() - this.getRow() == 1
            && Math.abs(this.getColumn() - piece.getColumn()) == 1;
  }
}
