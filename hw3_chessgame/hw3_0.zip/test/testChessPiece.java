import chess.Bishop;
import chess.Color;
import chess.King;
import chess.Rook;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class testChessPiece {
  Bishop bishop;
  Rook rook;
  King king;

  @Before
  public void setUp() {
    bishop = new Bishop(2, 2, Color.BLACK);
    rook = new Rook(0, 0, Color.WHITE);
    king = new King(0, 1, Color.BLACK);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalMoveOutOfRange() {
    bishop.canMove(8, 1);
    bishop.canMove(2, 18);
    bishop.canMove(-2, 2);
    rook.canMove(2, 18);
    rook.canMove(8, 1);
    rook.canMove(-1, 2);
    king.canMove(2, 0);
    king.canMove(0, 3);
    king.canMove(3, 2);
  }

  @Test
  public void testCanMove() {
    assertTrue(bishop.canMove(4, 4));
    assertTrue(bishop.canMove(1, 1));
    assertFalse(bishop.canMove(1, 4));
    assertFalse(bishop.canMove(1, 4));
    assertTrue(rook.canMove(5, 0));
    assertTrue(rook.canMove(0, 2));
    assertFalse(rook.canMove(2, 2));
    assertTrue(king.canMove(0, 0));
    assertTrue(king.canMove(0, 2));
    assertTrue(king.canMove(1, 0));
  }
}
