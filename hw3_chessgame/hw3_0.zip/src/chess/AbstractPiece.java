package chess;

public abstract class AbstractPiece implements ChessPiece {
  private int row;
  private int col;
  private Color color;

  public AbstractPiece(int row, int column, Color color) {
    this.row = row;
    this.col = column;
    this.color = color;
  }

  public int getRow() {
    return this.row;
  }

  public int getColumn() {
    return this.col;
  }

  public Color getColor() {
    return this.color;
  }

  public boolean checkRowColumn(int rowOrColumn) throws IllegalArgumentException{
    if (rowOrColumn < 0 || rowOrColumn > 7) {
      throw new IllegalArgumentException("Row or Column cannot be less than 0 or more than 7");
    }
    return true;
  }

  public boolean checkColor(ChessPiece other) {
    if (other.getColor() != this.getColor()) {
      return true;
    }
    return false;
  }

  public boolean canMove(int row, int col) {
    return checkRowColumn(col) && checkRowColumn(row);
  }

  public boolean canKill(ChessPiece piece) {
    return checkColor(piece);
  }
}
