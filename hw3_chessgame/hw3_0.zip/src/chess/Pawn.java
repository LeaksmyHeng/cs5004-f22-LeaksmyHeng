package chess;

public class Pawn extends AbstractPiece implements ChessPiece {
  public Pawn(int row, int column, Color color) {
    super(row, column, color);
  }

  @Override
  public boolean canMove(int row, int column) {
    if (super.canMove(row, column)) {
      if ((row - this.getRow() > 0) || (column - this.getColumn() > 0)) {
        if ((this.getRow() == 0) || (this.getRow() == 6)) {
          return this.getColumn() == column && Math.abs(row-this.getRow()) <= 2;
        }
        else {
          return this.getColumn() == column && Math.abs(row-this.getRow()) == 1;
        }
      }
      return false;
    }
    return false;
  }

  @Override
  public boolean canKill(ChessPiece piece) {
    return super.canKill(piece) && piece.getRow() - this.getRow() == 1
            && Math.abs(this.getColumn() - piece.getColumn()) == 1;
  }
}
