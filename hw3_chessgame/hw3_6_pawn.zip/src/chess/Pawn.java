package chess;

/**
 * Create a Pawn chess piece which implement ChessPiece interface.
 */
public class Pawn extends AbstractPiece implements ChessPiece {

  /**
   * Create a constructor for Bishop which take row, column and color.
   */
  public Pawn(int row, int column, Color color) throws IllegalArgumentException {
    super(row, column, color);
    if (row < 1 || row > 6) {
      throw new IllegalArgumentException("Pawn cannot have row less than 1 or greater than 6");
    }
  }

  @Override
  public boolean canMove(int row, int column) {
    if (super.canMove(row, column)) {
      if (this.getColor() == Color.BLACK) {
        if ((this.getRow() < 6) && (this.getColumn() - column == 1)
                && (row == this.getRow())) {
          return true;
        }
        else if ((this.getRow() == 6 && this.getRow() == row
                && this.getColumn() - column <= 2)) {
          return true;
        }
        return false;
      }
      if (this.getColor() == Color.WHITE) {
        if (this.getRow() == 1 && row == this.getRow()
                && column - this.getColumn() <= 2) {
          return true;
        }
        else if (this.getRow() > 1 && row == this.getRow()
                && column - this.getColumn() == 1) {
          return true;
        }
        return false;
      }
      return false;
    }
    return false;
  }

  @Override
  public boolean canKill(ChessPiece piece) {
    return super.canKill(piece) && piece.getRow() - this.getRow() == 1
            && Math.abs(this.getColumn() - piece.getColumn()) == 1;
  }
}
