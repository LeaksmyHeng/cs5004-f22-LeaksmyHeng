package registration;

import java.util.List;

public interface IRegistration {
  public int getRegistrationYear();
  public int getProductionYear();
  public IJurisdiction getJurisdiction();
  public List<Person> getOwners();      // return NON-MUTABLE list
  public int getMaxPassengers();
  public double calculateExciseTax();
}
