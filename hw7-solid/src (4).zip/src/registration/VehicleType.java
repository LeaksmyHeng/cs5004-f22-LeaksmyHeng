package registration;

public enum VehicleType { Motorcycle(2), Auto(5), Boat(10);

  private int maxPassenger;
  VehicleType(int maxPassenger) {
    this.maxPassenger = maxPassenger;
  }

  public int getMaxPassenger() {
    return maxPassenger;
  }

  public static VehicleType findVehicleType(String kind) {
    VehicleType vehicleKind = null;
    for (VehicleType type : VehicleType.values()) {
      if (type.name().equalsIgnoreCase(kind)) {
        vehicleKind = type;
        break;
      }
    }
    return vehicleKind;
  }

  public static void main(String[] args) {
    System.out.println(findVehicleType("Motorcycle"));
  }
}
