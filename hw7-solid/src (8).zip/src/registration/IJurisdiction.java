package registration;

public interface  IJurisdiction {
  default double exciseTax(IVehicle vehicle) { return 0.0;}
}
