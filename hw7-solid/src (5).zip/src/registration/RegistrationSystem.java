package registration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

public class RegistrationSystem {
  Set<IRegistration> vehicleSet = new HashSet<>();
  private List<IRegistration> registrationList;
  private static RegistrationSystem instance = new RegistrationSystem();

  public static RegistrationSystem getInstance() {
    return instance;
  }

  /**
   * Create a vehicle class.
   */
  public IVehicle createVehicle(String kind, String make, int productionYear, double purchasePrice)
          throws  IllegalArgumentException {
    if (VehicleType.findVehicleType(kind) == null) {
      throw new IllegalArgumentException("Kind cannot be null");
    }
    if (make == null || make.equals("")) {
        throw new IllegalArgumentException("Make of vehicles cannot be null.");
    }
    if (productionYear < 1900 || productionYear > 2023) {
      throw new IllegalArgumentException("Production year are in between 1900 and 2023");
    }
    if (purchasePrice < 0.0) {
      throw new IllegalArgumentException("Purchased price in createVehicle cannot be negative");
    }
    return new Vehicle(VehicleType.findVehicleType(kind), make, productionYear, purchasePrice);
  }

  /**
   * Register a vehicle class.
   */
  public void register(IVehicle vehicle, IJurisdiction jurisdiction, int registrationYear, List<Person> owners) {
    Registration registerVehicle = new Registration(owners, jurisdiction, registrationYear, vehicle);
    vehicleSet.add(registerVehicle);
  }

  /**
   * reset the system to initial "start state".
   */
  public void reboot() {
    vehicleSet.removeAll(vehicleSet);
  }

  /**
   * Get all registration class. answer an unmodifiable list.
   */
  public List<IRegistration> getAllRegistrations() {
    // convert set to list
    int numberOfElementInSet = vehicleSet.size();
    List <IRegistration> listOfRegistration = new ArrayList<IRegistration>(numberOfElementInSet);
    listOfRegistration.addAll(vehicleSet);
    registrationList = Collections.unmodifiableList(listOfRegistration);
    return registrationList;
  }

  /**
   * getFilteredList() takes a Predicate<IRegistration> and returns a sublist
   * that is filtered based on that query.
   * */
  public List<IRegistration> getFilteredList(Predicate<IRegistration> query) {
    if (query == null) {
      throw new IllegalArgumentException("Predicate query cannot be null");
    }
    List<IRegistration> registrationQuery = new ArrayList<IRegistration>();
    for (int i = 1; i <= getAllRegistrations().size(); i++) {
      if (query.test(getRegistration(i))) {
        registrationQuery.add(getRegistration(i));
      }
    }
    return registrationQuery;
  }

  /**
   * Create a getRegistration method.
   */
  public IRegistration getRegistration(int num) throws IndexOutOfBoundsException {
    if (num <= 0) {
      throw new IndexOutOfBoundsException("Number cannot be negative.");
    }
    return (registrationList.get(num - 1));
  }
}
