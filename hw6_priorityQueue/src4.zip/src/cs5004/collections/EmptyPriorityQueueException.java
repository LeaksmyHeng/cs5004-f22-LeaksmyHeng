package cs5004.collections;

public class EmptyPriorityQueueException extends Exception {
}