package cs5004.collections;

/**
 * Create a PriorityQueue class that will implement the PriorityQueue interface.
 */
public class ListPriorityQueue implements PriorityQueue {

  /**
   * Create a root node for our list PriorityQueue.
   */
  private PriorityNode root;

  public ListPriorityQueue(PriorityNode root) {
    this.root = root;
  }

  /**
   * Create an empty node.
   */
  public static PriorityQueue createEmpty() {
    PriorityQueue root = (PriorityQueue) new PriorityNode();
    return root;
  }

  /**
   * Checks if the priority queue is empty
   * @return true if the PQ is empty, false otherwise.
   */
  @Override
  public Boolean isEmpty() {
    if (this.root == null) {
      return true;
    }
    return false;
  }

  @Override
  public PriorityQueue add(Integer priority, String value) throws IllegalArgumentException {
    if (priority > 10 || priority < 1) {
      throw new IllegalArgumentException("Priority cannot be greater than 10 or less than 1");
    }
    else {
    }
    return null;
  }

  @Override
  public String peek() throws EmptyPriorityQueueException {
    return null;
  }

  @Override
  public PriorityQueue pop() throws EmptyPriorityQueueException {
    return null;
  }
}
