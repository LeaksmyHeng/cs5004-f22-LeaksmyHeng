package cs5004.collections;

/**
 * Create a constructor for ListPriorityQueue.
 */
public class PriorityNode {
  private int priority;
  private String value;
  private PriorityNode next;

  /**
   * Create an emptyNode.
   */
  public PriorityNode() {
    this.priority = -1;
    this.value = null;
    this.next = null;
  }

  /**
   * Create a non EmptyNode.
   */
  public PriorityNode(int priority, String value) {
    this.priority = priority;
    this.value = value;
    this.next = null;
  }

  /**
   * Create a setter method to set priority.
   */
  public void setPriority(int priority) {
    this.priority = priority;
  }

  /**
   * Create a setter method to set the value.
   */
  public void setValue(String value) {
    this.value = value;
  }

  /**
   * Create a setter method to point to the next value.
   */
  public void setNext(PriorityNode next) {
    this.next = next;
  }

  /**
   * Create a get priority method for PriorityNode.
   */
  public int getPriority() {
    return this.priority;
  }

  /**
   * Create a get value method.
   */
  public String getValue() {
    return this.getValue();
  }

  /**
   * Create a method to get next.
   */
  public PriorityNode getNext() {
    return this.next;
  }
}
