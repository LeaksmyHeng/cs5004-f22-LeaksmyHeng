package cs5004.collections;

/**
 * Create a PriorityQueue class that will implement the PriorityQueue interface.
 */
public class ListPriorityQueue implements PriorityQueue {

  /**
   * Create a root node for our list PriorityQueue.
   */
  private PriorityNode root;

  /**
   * Create an empty node.
   */
  public static PriorityQueue createEmpty() {
    PriorityQueue root = (PriorityQueue) new PriorityNode();
    root = null;
    return root;
  }

  /**
   * Checks if the priority queue is empty
   * @return true if the PQ is empty, false otherwise.
   */
  @Override
  public Boolean isEmpty() {
    if (this.root == null) {
      return true;
    }
    return false;
  }

  @Override
  public PriorityQueue add(Integer priority, String value) throws IllegalArgumentException {
    if (priority > 10) {
      throw new IllegalArgumentException("Priority cannot be greater than 10 or less than 1");
    }
    else if (priority < 1) {
      throw new IllegalArgumentException("Priority cannot be greater than 10 or less than 1");
    }
    else {
      PriorityNode node = new PriorityNode(priority, value);
      if (isEmpty()) {
        this.root = node;
      }
      else {
        PriorityNode temp = this.root;
      }
    }
    return null;
  }

  @Override
  public String peek() throws EmptyPriorityQueueException {
    if (this.root == null) {
      throw new EmptyPriorityQueueException();
    }
    // need to convert this to recursive
    else {
      PriorityNode temp = this.root;
      while (temp.getNext() != null) {
        temp = temp.getNext();
      }
      return temp.getValue();
    }
  }

  @Override
  public PriorityQueue pop() throws EmptyPriorityQueueException {
    if (this.root == null) {
      throw new EmptyPriorityQueueException();
    }
    // need to convert this to recursive
    else {
      PriorityNode temp = this.root;
      if (temp.getNext() == null) {
        this.root = null;
      }
      else {
        while (temp.getNext().getNext() != null) {
          temp = temp.getNext();
        }
        temp.setNext(null);
      }
    }
    return this;
  }
}
