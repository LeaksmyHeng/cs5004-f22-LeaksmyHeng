package cs5004.collections;

import java.util.Objects;

/**
 * Create a ListPriorityQueue concret method that implements priorityQueue.
 */
public class ListPriorityQueue implements PriorityQueue {
  private ListPriorityQueueNode head;

  /**
   * Create a static method for createEmpty.
   */
  public static PriorityQueue createEmpty() {
    return new ListPriorityQueueEmpty();
  }

  @Override
  public Boolean isEmpty() {
    if (head == null) {
      return true;
    }
    return false;
  }

  @Override
  public PriorityQueue add(Integer priority, String value) throws IllegalArgumentException {
    if (priority > 10 || priority < 1) {
      throw new IllegalArgumentException("Priority can't be less than 1 or greater than 10");
    }
    return head.add(priority, value);
  }

  @Override
  public String peek() throws EmptyPriorityQueueException {
    return null;
  }

  @Override
  public PriorityQueue pop() throws EmptyPriorityQueueException {
    return null;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ListPriorityQueue m = (ListPriorityQueue) o;
    return Objects.equals(m.head.getValue(), ((ListPriorityQueue) o).head.getValue())
            && Objects.equals(m.head.getPriority(), ((ListPriorityQueue) o).head.getPriority())
            && Objects.equals(m.head.getRest(), ((ListPriorityQueue) o).head.getRest());
  }

  /**
   * Create a hashcode.
   */
  public int hashCode() {
    return Objects.hash(head.getPriority(), head.getValue(), head.getRest());
  }
}
