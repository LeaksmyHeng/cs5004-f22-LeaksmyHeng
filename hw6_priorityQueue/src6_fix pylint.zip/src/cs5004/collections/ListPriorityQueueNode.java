package cs5004.collections;

/**
 * Create a ListPriorityQueue that will implement the PriorityQueue interface.
 */
public class ListPriorityQueueNode implements PriorityQueue {
  private int priority;
  private String value;
  private PriorityQueue rest;

  /**
   * Create a constructor for our ListPriorityQueueNode.
   */
  public ListPriorityQueueNode(int priority, String value, PriorityQueue rest) {
    this.priority = priority;
    this.value = value;
    this.rest = rest;
  }

  /**
   * Create a static method for createEmpty.
   */
  @Override
  public Boolean isEmpty() {
    return false;
  }

  @Override
  public PriorityQueue add(Integer priority, String value) throws IllegalArgumentException {
    if (priority > 10 || priority < 1) {
      throw new IllegalArgumentException("Priority can't be less than 1 or greater than 10");
    }
    else {
      if (priority == 1) {
        return new ListPriorityQueueNode(priority, value, this);
      }
      this.rest = this.rest.add(priority - 1, value);
    }
    return this;
  }

  @Override
  public String peek() throws EmptyPriorityQueueException {
    return null;
  }

  @Override
  public PriorityQueue pop() throws EmptyPriorityQueueException {
    return null;
  }

  /**
   * Create a getValue method for our Node.
   */
  public String getValue() {
    return this.value;
  }

  /**
   * Create a get priority for our node.
   */
  public int getPriority() {
    return this.priority;
  }

  /**
   * Create a get Next getter.
   */
  public PriorityQueue getRest() {
    return this.rest;
  }
}
