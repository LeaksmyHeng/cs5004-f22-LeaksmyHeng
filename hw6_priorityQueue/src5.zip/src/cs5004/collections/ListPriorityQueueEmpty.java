package cs5004.collections;

public class ListPriorityQueueEmpty implements PriorityQueue {
  @Override
  public Boolean isEmpty() {
    return true;
  }

  @Override
  public PriorityQueue add(Integer priority, String value) throws IllegalArgumentException {
    return new ListPriorityQueueNode(priority, value, this);
  }

  @Override
  public String peek() throws EmptyPriorityQueueException {
    throw new EmptyPriorityQueueException();
  }

  @Override
  public PriorityQueue pop() throws EmptyPriorityQueueException {
    throw new EmptyPriorityQueueException();
  }
}
