package cs5004.collections;

/**
 * Create an EmptyProrityQueue Exception.
 */
public class EmptyPriorityQueueException extends Exception {
}