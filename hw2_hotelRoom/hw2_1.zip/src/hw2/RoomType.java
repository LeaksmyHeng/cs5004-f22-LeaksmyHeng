package hw2;

/**
 * Create an enum that shows the three categories of the rooms.
 */
public enum RoomType {SINGLE_ROOM(1), DOUBLE_ROOM(2), FAMILY_ROOM(4);

  private int value;
  RoomType(int value) {this.value = value;}

  public int getValue() { return value; }

}
