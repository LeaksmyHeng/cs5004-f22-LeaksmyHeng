package Question9;

public interface IPumpComponent {

  void accept(IPumpComponentVisitor repairDrone);
}
