package question10;

public interface IListing {
  public double calculatePrice();
}
